This is team-work assignment, team members include:
Yuezhou Teng, UFID: 3676-2017
Danjie Lu, UFID: 3231-1202

Everything is working without bonus
 
The largest numbers that we ran with our code:
 
Gossip
Full : 3000
Line: 20000
Grid: 100000
Imperfect Grid: 50000

Pushsum
Full : 2000
Line: 2000
Grid: 3000
Imperfect Grid: 30000