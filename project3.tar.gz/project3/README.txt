This is team-work assignment, team members include:
Yuezhou Teng, UFID: 3676-2017
Danjie Lu, UFID: 3231-1202

All tasks are done except bonus
 
The largest network that our program can handle:
 
NumOfNodes: 9000, NumofMessages: 50
Avg Hops: 9.4985